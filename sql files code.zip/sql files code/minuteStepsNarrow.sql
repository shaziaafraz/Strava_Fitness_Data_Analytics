SELECT * FROM fitbase.minutestepsnarrow;
SET SQL_SAFE_UPDATES = 0;
--  understand structure
SELECT * 
FROM minutestepsnarrow
LIMIT 10;
-- Count how many duplicate rows exist in total
SELECT COUNT(*) - COUNT(DISTINCT Id, ActivityMinute, Steps) AS total_duplicates
FROM minutestepsnarrow;
-- Delete duplicate rows (same Id, timestamp, and steps)
DELETE FROM minuteStepsNarrow
WHERE (Id, ActivityMinute, Steps) IN (
    SELECT Id, ActivityMinute, Steps
    FROM (
        SELECT Id, ActivityMinute, Steps,
               ROW_NUMBER() OVER (PARTITION BY Id, ActivityMinute, Steps ORDER BY Id) AS rn
        FROM minutestepsnarrow
    ) t
    WHERE rn > 1
);
-- Remove negative or unrealistic step counts
DELETE FROM minutestepsnarrow
WHERE Steps < 0;
--  Who are the most active users overall?
SELECT Id, SUM(Steps) AS total_steps
FROM minutestepsnarrow
GROUP BY Id
ORDER BY total_steps DESC
LIMIT 10;
--  On average, how many steps does each user take per active minute?
SELECT Id, AVG(Steps) AS avg_steps_per_minute
FROM minutestepsnarrow
GROUP BY Id
ORDER BY avg_steps_per_minute DESC;
--  What percentage of minutes have zero steps (inactive time)?
SELECT 
    (SUM(CASE WHEN Steps = 0 THEN 1 ELSE 0 END) * 100.0 / COUNT(*)) AS percent_inactive
FROM minutestepsnarrow;
DESCRIBE minutestepsnarrow;
SET SQL_SAFE_UPDATES = 1;
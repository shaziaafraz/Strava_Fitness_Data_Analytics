SELECT * FROM fitbase.dailycalories;
SET SQL_SAFE_UPDATES = 0;
--  Change the data type of ActivityDay to DATE if not already set
ALTER TABLE dailycalories
MODIFY COLUMN ActivityDay DATE;
--  Remove duplicate records based on Id and ActivityDay
DELETE n1 FROM dailycalories n1
INNER JOIN dailycalories n2
WHERE n1.id > n2.id
  AND n1.Id = n2.Id
  AND n1.ActivityDay = n2.ActivityDay;
--  Remove rows with NULL, zero, or negative Calories values
DELETE FROM dailycalories
WHERE Calories IS NULL
   OR Calories <= 0;
--  Remove rows with NULL values in Id or ActivityDay, ensuring no incomplete records
DELETE FROM dailycalories
WHERE Id IS NULL
   OR ActivityDay IS NULL;
--  Preview cleaned data to confirm results
SELECT * FROM dailycalories LIMIT 10; 
-- Check the average daily calories burned by all users
-- Helps understand the general calorie expenditure of users
SELECT ROUND(AVG(Calories), 2) AS avg_daily_calories
FROM dailycalories;
--  Find the user with the highest average calories burned
-- Identifies the most active/high-calorie-burning individual.
SELECT Id, ROUND(AVG(Calories), 2) AS avg_calories
FROM dailycalories
GROUP BY Id
ORDER BY avg_calories DESC
LIMIT 1;
--  Find the day with the highest calories burned overall
-- Reveals peak activity day across all users.
SELECT ActivityDay, SUM(Calories) AS total_calories
FROM dailycalories
GROUP BY ActivityDay
ORDER BY total_calories DESC
LIMIT 1;
SET SQL_SAFE_UPDATES = 1;
   
  
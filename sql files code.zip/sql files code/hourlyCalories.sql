SELECT * FROM fitbase.hourlycalories;
SET SQL_SAFE_UPDATES = 0;
-- Check for duplicates
SELECT Id, ActivityHour, COUNT(*) AS dup_count
FROM hourlycalories
GROUP BY Id, ActivityHour
HAVING COUNT(*) > 1;
-- Find NULL or zero calories
SELECT * 
FROM hourlycalories
WHERE Calories IS NULL OR Calories < 0;
-- Average calories burned per hour across all users
--  Shows calorie burn patterns throughout the day
SELECT HOUR(ActivityHour) AS hour_of_day, 
       ROUND(AVG(Calories), 2) AS avg_calories
FROM hourlycalories
GROUP BY hour_of_day
ORDER BY hour_of_day;
--  Compare average calories burned during working hours vs non-working hours
--  Checks if users burn more calories during the day vs evening/night.
SELECT 
    CASE 
        WHEN HOUR(ActivityHour) BETWEEN 9 AND 17 THEN 'Work Hours'
        ELSE 'Non-Work Hours'
    END AS time_block,
    ROUND(AVG(Calories), 2) AS avg_calories
FROM hourlycalories
GROUP BY time_block;
--  Identify the user with the highest hourly calorie burn (max value recorded)
--  Finding extreme calorie-burning sessions (like intense workouts)
SELECT Id, ActivityHour, Calories
FROM hourlycalories
ORDER BY Calories DESC
LIMIT 1;
SET SQL_SAFE_UPDATES = 1;



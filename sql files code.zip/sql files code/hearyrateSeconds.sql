SELECT * FROM fitbase.heartrateseconds;
DESCRIBE heartrateseconds;
SET SQL_SAFE_UPDATES = 0;
ALTER TABLE heartrateseconds ADD COLUMN pk_id INT AUTO_INCREMENT PRIMARY KEY;
SELECT COUNT(*) AS NullCount
FROM heartrateseconds
WHERE Id IS NULL OR Time IS NULL OR Value IS NULL;
DELETE FROM heartrateseconds
WHERE Id IS NULL OR Time IS NULL OR Value IS NULL;
--  Resting Heart Rate: Find the minimum heart rate per user per day (proxy for resting HR)
SELECT 
  Id,
  DATE(Time) AS Date,
  MIN(Value) AS RestingHeartRate
FROM heartrateseconds
GROUP BY Id, DATE(Time)
ORDER BY Id, Date;
-- 2. Active vs Rest Periods: Identify minutes with average heart rate above a threshold (e.g., 100 BPM) indicating activity
SELECT
  Id,
  DATE(Time) AS Date,
  HOUR(Time) AS Hour,
  MINUTE(Time) AS Minute,
  AVG(Value) AS AvgHeartRate,
  CASE WHEN AVG(Value) > 100 THEN 'Active' ELSE 'Rest' END AS ActivityStatus
FROM heartrateseconds
GROUP BY Id, Date, Hour, Minute
ORDER BY Id, Date, Hour, Minute;
--  Daily Average, Minimum, and Maximum Heart Rate for trend analysis
SELECT
  Id,
  DATE(Time) AS Date,
  AVG(Value) AS AvgHeartRate,
  MIN(Value) AS MinHeartRate,
  MAX(Value) AS MaxHeartRate
FROM heartrateseconds
GROUP BY Id, Date
ORDER BY Id, Date;
DESCRIBE heartrateseconds;
-- Delete any record where Id, Time, or Value is NULL
DELETE FROM heartrateseconds
WHERE Id IS NULL OR Time IS NULL OR Value IS NULL;
SET SQL_SAFE_UPDATES = 1;


SELECT * FROM fitbase.hourlysteps;
SET SQL_SAFE_UPDATES = 0;
-- Check duplicates
SELECT Id, ActivityHour, COUNT(*) AS dup_count
FROM hourlysteps
GROUP BY Id, ActivityHour
HAVING dup_count > 1;
-- Delete duplicates (keep first occurrence)
DELETE FROM hourlysteps
WHERE (Id, ActivityHour, StepTotal) IN (
    SELECT Id, ActivityHour, StepTotal
    FROM (
        SELECT Id, ActivityHour, StepTotal,
               ROW_NUMBER() OVER (PARTITION BY Id, ActivityHour ORDER BY Id) AS rn
        FROM hourlysteps
    ) t
    WHERE rn > 1
);
-- Check for NULL or negative step counts
SELECT * 
FROM hourlysteps
WHERE StepTotal IS NULL OR StepTotal < 0;
-- Remove invalid rows
DELETE FROM hourlysteps
WHERE StepTotal IS NULL OR StepTotal < 0;
--  Compare steps during Work Hours (9AM–5PM) vs Non-Work Hours
--  Helps see if users walk more during office hours or outside them.
SELECT 
    CASE 
        WHEN HOUR(ActivityHour) BETWEEN 9 AND 17 THEN 'Work Hours'
        ELSE 'Non-Work Hours'
    END AS time_block,
    ROUND(AVG(StepTotal), 2) AS avg_steps
FROM hourlysteps
GROUP BY time_block;
--  Weekday vs Weekend step activity
--  Shows whether people tend to take more steps on weekends or weekdays.
SELECT 
    CASE 
        WHEN DAYOFWEEK(ActivityHour) IN (1,7) THEN 'Weekend'
        ELSE 'Weekday'
    END AS day_type,
    ROUND(AVG(StepTotal), 2) AS avg_steps
FROM hourlysteps
GROUP BY day_type;
--  Identify the user with the highest recorded hourly step count
-- Finds the peak activity event (e.g., intense workout or long walk).
SELECT Id, ActivityHour, StepTotal
FROM hourlysteps
ORDER BY StepTotal DESC
LIMIT 1;
SET SQL_SAFE_UPDATES = 1;




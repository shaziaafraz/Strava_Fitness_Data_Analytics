SELECT * FROM fitbase.dailyintensities;
-- Disable safe update mode
SET SQL_SAFE_UPDATES = 0;
--  Check total rows and count NOT NULL values in critical columns
SELECT 
    COUNT(*) AS total_rows,
    COUNT(Id) AS id_not_null,
    COUNT(ActivityDay) AS activityday_not_null,
    COUNT(SedentaryMinutes) AS sedentary_not_null
FROM dailyintensities;
--  Identify duplicate records 
SELECT Id, ActivityDay, COUNT(*) AS count_duplicates
FROM dailyintensities
GROUP BY Id, ActivityDay
HAVING count_duplicates > 1;
-- Step 3: Remove rows with NULL values in critical columns 
DELETE FROM dailyintensities
WHERE Id IS NULL OR ActivityDay IS NULL;
--  Check for negative or invalid values in numeric columns
SELECT * FROM dailyintensities
WHERE 
    SedentaryMinutes < 0 OR LightlyActiveMinutes < 0 OR
    FairlyActiveMinutes < 0 OR VeryActiveMinutes < 0 OR
    SedentaryActiveDistance < 0 OR LightActiveDistance < 0 OR
    ModeratelyActiveDistance < 0 OR VeryActiveDistance < 0;
--  Validate cleaning by checking summary stats
SELECT 
    MIN(SedentaryMinutes) AS min_sedentary,
    MAX(SedentaryMinutes) AS max_sedentary,
    AVG(SedentaryMinutes) AS avg_sedentary,
    MIN(LightlyActiveMinutes) AS min_light,
    MAX(LightlyActiveMinutes) AS max_light,
    AVG(LightlyActiveMinutes) AS avg_light,
    COUNT(DISTINCT Id) AS unique_users,
    COUNT(DISTINCT ActivityDay) AS unique_days
FROM dailyintensities;
--  Which user is the most active (highest average very active minutes)?
-- Identifies the most physically active user.
SELECT Id, ROUND(AVG(VeryActiveMinutes), 2) AS avg_very_active
FROM dailyintensities
GROUP BY Id
ORDER BY avg_very_active DESC
LIMIT 1;
--  Find the day with the highest total very active minutes across all users
--  Reveals the peak day of intense physical activity.
SELECT ActivityDay, SUM(VeryActiveMinutes) AS total_very_active
FROM dailyintensities
GROUP BY ActivityDay
ORDER BY total_very_active DESC
LIMIT 1;
-- Compare weekdays vs weekends for activity intensity
--  Shows if users are more active on weekdays or weekends.
SELECT 
    CASE 
        WHEN DAYOFWEEK(ActivityDay) IN (1,7) THEN 'Weekend'
        ELSE 'Weekday'
    END AS day_type,
    ROUND(AVG(VeryActiveMinutes), 2) AS avg_very_active,
    ROUND(AVG(SedentaryMinutes), 2) AS avg_sedentary
FROM dailyintensities
GROUP BY day_type;
SET SQL_SAFE_UPDATES = 1;
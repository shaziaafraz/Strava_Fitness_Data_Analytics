SELECT * FROM fitbase.dailyactivity;
SET SQL_SAFE_UPDATES = 0;
DELETE n1 FROM dailyactivity n1
INNER JOIN dailyactivity n2
WHERE n1.id > n2.id
AND n1.Id = n2.Id
AND n1.ActivityDate = n2.ActivityDate;
DELETE FROM dailyactivity
WHERE TotalSteps <= 0 
   OR TotalDistance <= 0
   OR Calories <= 0;
DELETE FROM dailyactivity
WHERE VeryActiveMinutes < 0
   OR FairlyActiveMinutes < 0
   OR LightlyActiveMinutes < 0
   OR SedentaryMinutes < 0;
-- Average steps per user per day
-- Helps see if users are meeting the 10,000 daily step recommendation
SELECT Id, ROUND(AVG(TotalSteps), 0) AS avg_daily_steps
FROM dailyactivity
GROUP BY Id
ORDER BY avg_daily_steps DESC;
-- % of days where users reached 10,000+ steps
-- Gives an idea of how active users are overall
SELECT 
    Id,
    ROUND(SUM(CASE WHEN TotalSteps >= 10000 THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) AS pct_days_10000_steps
FROM dailyactivity
GROUP BY Id
ORDER BY pct_days_10000_steps DESC;
-- Average calories burned per user
-- Useful for understanding overall energy expenditure
SELECT Id, ROUND(AVG(Calories), 0) AS avg_daily_calories
FROM dailyactivity
GROUP BY Id
ORDER BY avg_daily_calories DESC;
-- Average activity intensity breakdown (minutes per day)
-- Shows if users are more sedentary or active
SELECT 
    Id,
    ROUND(AVG(SedentaryMinutes), 0) AS avg_sedentary_minutes,
    ROUND(AVG(LightlyActiveMinutes), 0) AS avg_light_minutes,
    ROUND(AVG(FairlyActiveMinutes), 0) AS avg_fairly_minutes,
    ROUND(AVG(VeryActiveMinutes), 0) AS avg_very_minutes
FROM dailyactivity
GROUP BY Id
ORDER BY avg_very_minutes DESC;
SET SQL_SAFE_UPDATES = 1;
SELECT *
FROM dailyactivity
WHERE TotalDistance < (VeryActiveDistance + ModeratelyActiveDistance + LightActiveDistance + SedentaryActiveDistance);





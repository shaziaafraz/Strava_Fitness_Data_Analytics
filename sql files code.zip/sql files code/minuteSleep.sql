SELECT * FROM fitbase.minutesleep;
SET SQL_SAFE_UPDATES = 0;
-- understand structure
SELECT * 
FROM minutesleep
LIMIT 10;
-- Delete duplicate rows (same user, datetime, and value)
DELETE FROM minutesleep
WHERE (Id, date, value, logId) IN (
    SELECT Id, date, value, logId
    FROM (
        SELECT Id, date, value, logId,
               ROW_NUMBER() OVER (PARTITION BY Id, date, value, logId ORDER BY Id) AS rn
        FROM minutesleep
    ) t
    WHERE rn > 1
);
-- Check how many nulls exist 
SELECT 
    SUM(CASE WHEN Id IS NULL THEN 1 ELSE 0 END) AS null_ids,
    SUM(CASE WHEN date IS NULL THEN 1 ELSE 0 END) AS null_dates,
    SUM(CASE WHEN value IS NULL THEN 1 ELSE 0 END) AS null_values
FROM minutesleep;
-- converting date from txt to date type
ALTER TABLE minutesleep
ADD COLUMN date_clean DATETIME;
UPDATE minutesleep
SET date_clean = STR_TO_DATE(date, '%c/%e/%Y %r');

-- Some datasets use 1=Asleep, 2=Restless, 3=Awake. 
-- Let’s normalize it into readable labels
ALTER TABLE minutesleep ADD COLUMN sleep_stage VARCHAR(20);
UPDATE minutesleep
SET sleep_stage = CASE 
                     WHEN value = 1 THEN 'Asleep'
                     WHEN value = 2 THEN 'Restless'
                     WHEN value = 3 THEN 'Awake'
                     ELSE 'Unknown'
                  END;
--  Which sleep stage occurs most frequently overall?
SELECT sleep_stage, COUNT(*) AS stage_count
FROM minutesleep
GROUP BY sleep_stage
ORDER BY stage_count DESC;
--  On average, how many minutes does each user spend in each sleep stage?
SELECT Id, sleep_stage, COUNT(*) AS minutes_spent
FROM minutesleep
GROUP BY Id, sleep_stage
ORDER BY Id, minutes_spent DESC;
--  For each user, calculate restless ratio = restless minutes / total minutes
SELECT Id,
       SUM(CASE WHEN sleep_stage = 'Restless' THEN 1 ELSE 0 END) * 1.0 /
       COUNT(*) AS restless_ratio
FROM minutesleep
GROUP BY Id
ORDER BY restless_ratio DESC
LIMIT 5;
DESCRIBE minutesleep;
SET SQL_SAFE_UPDATES = 1;
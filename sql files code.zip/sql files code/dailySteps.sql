SELECT * FROM fitbase.dailysteps;
SET SQL_SAFE_UPDATES = 0;
--  Inspect total rows and count NOT NULLs in key columns
SELECT 
    COUNT(*) AS total_rows,
    COUNT(Id) AS id_not_null,
    COUNT(ActivityDay) AS activityday_not_null,
    COUNT(StepTotal) AS steptotal_not_null
FROM dailysteps;
--  Check for duplicates 
SELECT Id, ActivityDay, COUNT(*) AS duplicate_count
FROM dailysteps
GROUP BY Id, ActivityDay
HAVING duplicate_count > 1;
--  Remove rows with NULLs in critical columns 
DELETE FROM dailysteps
WHERE Id IS NULL OR ActivityDay IS NULL OR StepTotal IS NULL;
-- Check for invalid or negative StepTotal values
SELECT *
FROM dailysteps
WHERE StepTotal < 0;
-- Step 8: Summary statistics to validate cleaning
SELECT 
    MIN(StepTotal) AS min_steps,
    MAX(StepTotal) AS max_steps,
    AVG(StepTotal) AS avg_steps,
    COUNT(DISTINCT Id) AS unique_users,
    COUNT(DISTINCT ActivityDay) AS unique_days
FROM dailysteps;
--  Find the least active user (lowest average steps per day)
--  Identifies the least active user who may have a sedentary lifestyle
SELECT Id, ROUND(AVG(StepTotal), 2) AS avg_steps
FROM dailysteps
GROUP BY Id
ORDER BY avg_steps ASC
LIMIT 1;
--  Peak step count day across all users
-- Identifies the day when users collectively walked the most.
SELECT ActivityDay, SUM(StepTotal) AS total_steps
FROM dailysteps
GROUP BY ActivityDay
ORDER BY total_steps DESC
LIMIT 1;
SET SQL_SAFE_UPDATES = 1;
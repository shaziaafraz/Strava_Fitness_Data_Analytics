SELECT * FROM fitbase.minutecaloriesnarrow;
SET SQL_SAFE_UPDATES = 0;
-- Check for duplicates
SELECT Id, ActivityMinute, COUNT(*) AS dup_count
FROM minutecaloriesNarrow
GROUP BY Id, ActivityMinute
HAVING dup_count > 1;
-- Delete duplicates (keep first occurrence)
DELETE FROM minutecaloriesNarrow
WHERE (Id, ActivityMinute, Calories) IN (
    SELECT Id, ActivityMinute, Calories
    FROM (
        SELECT Id, ActivityMinute, Calories,
               ROW_NUMBER() OVER (PARTITION BY Id, ActivityMinute ORDER BY Id) AS rn
        FROM minutecaloriesNarrow
    ) t
    WHERE rn > 1
);
-- Check for NULL or negative calorie values
SELECT * 
FROM minutecaloriesNarrow
WHERE Calories IS NULL OR Calories < 0;
-- Remove invalid rows
DELETE FROM minutecaloriesNarrow
WHERE Calories IS NULL OR Calories < 0;
-- Find the peak calorie-burning minute across all users
--  Identifies the single most intense activity moment
SELECT Id, ActivityMinute, Calories
FROM minutecaloriesNarrow
ORDER BY Calories DESC
LIMIT 1;
--  Compare weekday vs weekend calorie burn (minute-level)
--  Shows if people burn more calories per minute during weekends vs weekdays.
SELECT 
    CASE 
        WHEN DAYOFWEEK(ActivityMinute) IN (1,7) THEN 'Weekend'
        ELSE 'Weekday'
    END AS day_type,
    ROUND(AVG(Calories), 2) AS avg_calories_per_min
FROM minutecaloriesnarrow
GROUP BY day_type;
--  Detect high-intensity minutes (Calories > 10 per min) per user
--  Finds users with the most high-intensity workout minutes.
SELECT Id, COUNT(*) AS high_intensity_minutes
FROM minutecaloriesnarrow
WHERE Calories > 10
GROUP BY Id
ORDER BY high_intensity_minutes DESC
LIMIT 5;
SET SQL_SAFE_UPDATES = 1;


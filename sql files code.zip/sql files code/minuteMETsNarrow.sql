SELECT * FROM fitbase.minutemetsnarrow;
SET SQL_SAFE_UPDATES = 0;
-- 1. Create a cleaned table
CREATE TABLE minute_mets_cleaned AS
SELECT DISTINCT
    Id,
    -- Convert text datetime into proper DATETIME
    STR_TO_DATE(ActivityMinute, '%m/%d/%Y %h:%i:%s %p') AS ActivityMinute,
    -- Ensure METs is numeric
    CAST(METs AS UNSIGNED) AS METs
FROM minutemetsnarrow
WHERE ActivityMinute IS NOT NULL
  AND METs IS NOT NULL;
SELECT Id, ActivityMinute, COUNT(*) AS dup_count
FROM minute_mets_cleaned
GROUP BY Id, ActivityMinute
HAVING dup_count > 1;
--  primary key
ALTER TABLE minute_mets_cleaned
ADD COLUMN entry_id INT AUTO_INCREMENT PRIMARY KEY;
--  remove duplicates
DELETE t1
FROM minute_mets_cleaned t1
JOIN minute_mets_cleaned t2
  ON t1.Id = t2.Id
 AND t1.ActivityMinute = t2.ActivityMinute
 AND t1.METs = t2.METs
 AND t1.entry_id > t2.entry_id;
 -- verify dupliactes
 SELECT Id, ActivityMinute, COUNT(*) AS dup_count
FROM minute_mets_cleaned
GROUP BY Id, ActivityMinute, METs
HAVING dup_count > 1;
--  At what hours of the day do users burn the most energy (higher METs)?
-- Grouping by hour to calculate the average METs.
SELECT 
    HOUR(ActivityMinute) AS hour_of_day,
    AVG(METs) AS avg_mets
FROM minute_mets_cleaned
GROUP BY HOUR(ActivityMinute)
ORDER BY avg_mets DESC;
--  Are users more active during weekdays or weekends?
-- DAYOFWEEK(): 1 = Sunday, 7 = Saturday
SELECT 
    CASE 
        WHEN DAYOFWEEK(ActivityMinute) IN (1,7) THEN 'Weekend'
        ELSE 'Weekday'
    END AS day_type,
    AVG(METs) AS avg_mets
FROM minute_mets_cleaned
GROUP BY day_type;
--  Who are the most active users overall?
-- Summing total METs per user to rank them.
SELECT 
    Id,
    SUM(METs) AS total_mets
FROM minute_mets_cleaned
GROUP BY Id
ORDER BY total_mets DESC
LIMIT 5;
SET SQL_SAFE_UPDATES = 1;
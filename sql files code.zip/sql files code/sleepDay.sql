SELECT * FROM fitbase.sleepday;
SET SQL_SAFE_UPDATES = 0;
-- View first 10 rows
SELECT * 
FROM sleepday
LIMIT 10;
-- List the actual duplicate rows (if any)
SELECT Id, SleepDay, TotalSleepRecords, TotalMinutesAsleep, TotalTimeInBed, COUNT(*) AS dup_count
FROM sleepday
GROUP BY Id, SleepDay, TotalSleepRecords, TotalMinutesAsleep, TotalTimeInBed
HAVING COUNT(*) > 1
ORDER BY dup_count DESC;
-- Delete duplicate rows (same user, date, and sleep stats)
DELETE FROM sleepday
WHERE (Id, SleepDay, TotalSleepRecords, TotalMinutesAsleep, TotalTimeInBed) IN (
    SELECT Id, SleepDay, TotalSleepRecords, TotalMinutesAsleep, TotalTimeInBed
    FROM (
        SELECT Id, SleepDay, TotalSleepRecords, TotalMinutesAsleep, TotalTimeInBed,
               ROW_NUMBER() OVER (
                   PARTITION BY Id, SleepDay, TotalSleepRecords, TotalMinutesAsleep, TotalTimeInBed
                   ORDER BY Id
               ) AS rn
        FROM sleepday
    ) t
    WHERE rn > 1
);
-- Check for NULLs
SELECT 
    SUM(CASE WHEN Id IS NULL THEN 1 ELSE 0 END) AS null_ids,
    SUM(CASE WHEN SleepDay IS NULL THEN 1 ELSE 0 END) AS null_dates,
    SUM(CASE WHEN TotalMinutesAsleep IS NULL THEN 1 ELSE 0 END) AS null_asleep,
    SUM(CASE WHEN TotalTimeInBed IS NULL THEN 1 ELSE 0 END) AS null_inbed
FROM sleepday;
-- Remove rows with missing crucial values
DELETE FROM sleepday
WHERE Id IS NULL OR SleepDay IS NULL OR TotalMinutesAsleep IS NULL OR TotalTimeInBed IS NULL;
--  On average, how many minutes does each user sleep?
SELECT Id, 
       ROUND(AVG(TotalMinutesAsleep), 2) AS avg_minutes_asleep
FROM sleepDay_merged
GROUP BY Id
ORDER BY avg_minutes_asleep DESC;
--  Sleep efficiency = asleep minutes / total time in bed
SELECT Id,
       ROUND(AVG(TotalMinutesAsleep * 100.0 / TotalTimeInBed), 2) AS avg_sleep_efficiency
FROM sleepday
GROUP BY Id
ORDER BY avg_sleep_efficiency ASC;
-- On which weekdays do people sleep the most?
SELECT DAYNAME(SleepDay) AS weekday,
       ROUND(AVG(TotalMinutesAsleep), 2) AS avg_minutes_asleep
FROM sleepday
GROUP BY DAYNAME(SleepDay)
ORDER BY avg_minutes_asleep DESC;
DESCRIBE sleepday;
SET SQL_SAFE_UPDATES = 1;


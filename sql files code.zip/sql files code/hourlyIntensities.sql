SELECT * FROM fitbase.hourlyintensities;
SET SQL_SAFE_UPDATES = 0;
-- Check duplicates
SELECT 
    Id, ActivityHour, COUNT(*) AS dup_count
FROM
    hourlyintensities
GROUP BY Id , ActivityHour
HAVING dup_count > 1;
-- Check for NULL or negative values
SELECT * 
FROM hourlyintensities
WHERE TotalIntensity IS NULL 
   OR AverageIntensity IS NULL 
   OR TotalIntensity < 0 
   OR AverageIntensity < 0;
--  Compare activity intensity during Work Hours (9AM–5PM) vs Non-Work Hours
-- Shows whether people are more active during working hours or outside them.
SELECT 
    CASE 
        WHEN HOUR(ActivityHour) BETWEEN 9 AND 17 THEN 'Work Hours'
        ELSE 'Non-Work Hours'
    END AS time_block,
    ROUND(AVG(TotalIntensity), 2) AS avg_total_intensity
FROM hourlyintensities
GROUP BY time_block;
--  Find the user with the highest average intensity
--  Identifies the most active user based on hourly activity.
SELECT Id, ROUND(AVG(TotalIntensity), 2) AS avg_total_intensity
FROM hourlyintensities
GROUP BY Id
ORDER BY avg_total_intensity DESC
LIMIT 1;
--  Compare weekday vs weekend activity intensity
-- Helps see if users are more active on weekends or weekdays.
SELECT 
    CASE 
        WHEN DAYOFWEEK(ActivityHour) IN (1,7) THEN 'Weekend'
        ELSE 'Weekday'
    END AS day_type,
    ROUND(AVG(TotalIntensity), 2) AS avg_total_intensity,
    ROUND(AVG(AverageIntensity), 2) AS avg_avg_intensity
FROM hourlyintensities
GROUP BY day_type;
SET SQL_SAFE_UPDATES = 1;





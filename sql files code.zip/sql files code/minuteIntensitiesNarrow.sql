SELECT * FROM fitbase.minuteintensitiesnarrow;
SET SQL_SAFE_UPDATES = 0;
-- 1. Create a cleaned table
CREATE TABLE minute_intensities_cleaned AS
SELECT DISTINCT
    Id,
    STR_TO_DATE(ActivityMinute, '%m/%d/%Y %h:%i:%s %p') AS ActivityMinute,
    CAST(Intensity AS UNSIGNED) AS Intensity
FROM minuteintensitiesnarrow
WHERE ActivityMinute IS NOT NULL
  AND Intensity IS NOT NULL;
--  duplicates
SELECT Id, ActivityMinute, COUNT(*) AS dup_count
FROM minute_intensities_cleaned
GROUP BY Id, ActivityMinute
HAVING dup_count > 1;
SELECT * 
FROM minute_intensities_cleaned
ORDER BY Id, ActivityMinute
LIMIT 100;
--  Which hours of the day are users most active?
-- This groups by hour and finds the average intensity.
SELECT 
    HOUR(ActivityMinute) AS hour_of_day,
    AVG(Intensity) AS avg_intensity
FROM minute_intensities_cleaned
GROUP BY HOUR(ActivityMinute)
ORDER BY avg_intensity DESC;
--  Do users have higher intensity on weekdays or weekends?
-- DAYOFWEEK(): 1=Sunday, 7=Saturday
SELECT 
    CASE 
        WHEN DAYOFWEEK(ActivityMinute) IN (1,7) THEN 'Weekend'
        ELSE 'Weekday'
    END AS day_type,
    AVG(Intensity) AS avg_intensity
FROM minute_intensities_cleaned
GROUP BY day_type;
--  Who are the most active users overall?
-- Summing intensity values per user to find top 5.
SELECT 
    Id,
    SUM(Intensity) AS total_intensity
FROM minute_intensities_cleaned
GROUP BY Id
ORDER BY total_intensity DESC
LIMIT 5;
SET SQL_SAFE_UPDATES = 1;